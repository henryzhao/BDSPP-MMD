package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "路测设备",
    tags = "路测设备"
)
@RestController
@RequestMapping("nwpyfu")
public class nwpyfu {
  @ApiOperation(
      value = "上传车辆状态",
      notes = "上传车辆状态"
  )
  @RequestMapping(
      value = "kjnvsz",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> kjnvsz(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "播发路况消息",
      notes = "播发路况消息"
  )
  @RequestMapping(
      value = "pmndvg",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> pmndvg(String[] args) {
    return null;
  }
}
