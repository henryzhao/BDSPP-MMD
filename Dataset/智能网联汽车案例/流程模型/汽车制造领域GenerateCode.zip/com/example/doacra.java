package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "汽车制造商",
    tags = "汽车制造商"
)
@RestController
@RequestMapping("doacra")
public class doacra {
  @ApiOperation(
      value = "制造汽车",
      notes = "制造汽车"
  )
  @RequestMapping(
      value = "ahayeh",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> ahayeh(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "车辆使用",
      notes = "车辆使用"
  )
  @RequestMapping(
      value = "tlzbbu",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> tlzbbu(String[] args) {
    return null;
  }
}
