package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "智能网联汽车平台",
    tags = "智能网联汽车平台"
)
@RestController
@RequestMapping("lobzpp")
public class lobzpp {
  @ApiOperation(
      value = "车辆调度",
      notes = "车辆调度"
  )
  @RequestMapping(
      value = "vaasuh",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> vaasuh(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "规划路线",
      notes = "规划路线"
  )
  @RequestMapping(
      value = "nfmcke",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> nfmcke(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "身份认证",
      notes = "身份认证"
  )
  @RequestMapping(
      value = "dbdinw",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> dbdinw(String[] args) {
    return null;
  }
}
