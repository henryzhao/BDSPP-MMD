package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "就诊人员",
    tags = "就诊人员"
)
@RestController
@RequestMapping("bdebhc")
public class bdebhc {
  @ApiOperation(
      value = "登陆",
      notes = "登陆"
  )
  @RequestMapping(
      value = "kzgoiz",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> kzgoiz(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "就诊问询",
      notes = "就诊问询"
  )
  @RequestMapping(
      value = "tasxed",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> tasxed(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "支付",
      notes = "支付"
  )
  @RequestMapping(
      value = "dsfnvj",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> dsfnvj(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "结果查看",
      notes = "结果查看"
  )
  @RequestMapping(
      value = "lgdfdx",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> lgdfdx(String[] args) {
    return null;
  }
}
