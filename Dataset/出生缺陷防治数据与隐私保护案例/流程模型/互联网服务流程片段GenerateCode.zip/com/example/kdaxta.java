package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "互联网健康教育平台",
    tags = "互联网健康教育平台"
)
@RestController
@RequestMapping("kdaxta")
public class kdaxta {
  @ApiOperation(
      value = "咨询确认",
      notes = "咨询确认"
  )
  @RequestMapping(
      value = "vmkmiv",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> vmkmiv(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "信息转发",
      notes = "信息转发"
  )
  @RequestMapping(
      value = "kjcsuo",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> kjcsuo(String[] args) {
    return null;
  }
}
