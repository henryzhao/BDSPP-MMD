package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "医疗人员",
    tags = "医疗人员"
)
@RestController
@RequestMapping("ruizss")
public class ruizss {
  @ApiOperation(
      value = "登陆",
      notes = "登陆"
  )
  @RequestMapping(
      value = "fyzbow",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> fyzbow(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "挂号",
      notes = "挂号"
  )
  @RequestMapping(
      value = "qiobvm",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> qiobvm(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "支付",
      notes = "支付"
  )
  @RequestMapping(
      value = "avmpaz",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> avmpaz(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "就诊提醒",
      notes = "就诊提醒"
  )
  @RequestMapping(
      value = "fwdwji",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> fwdwji(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "查看报告",
      notes = "查看报告"
  )
  @RequestMapping(
      value = "kwijnd",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> kwijnd(String[] args) {
    return null;
  }
}
