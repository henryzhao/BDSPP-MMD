package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "医患信息管理系统",
    tags = "医患信息管理系统"
)
@RestController
@RequestMapping("erkqih")
public class erkqih {
  @ApiOperation(
      value = "就诊信息确认",
      notes = "就诊信息确认"
  )
  @RequestMapping(
      value = "smknrg",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> smknrg(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "检测问诊",
      notes = "检测问诊"
  )
  @RequestMapping(
      value = "asqygs",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> asqygs(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "档案信息管理",
      notes = "档案信息管理"
  )
  @RequestMapping(
      value = "veqfle",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> veqfle(String[] args) {
    return null;
  }
}
