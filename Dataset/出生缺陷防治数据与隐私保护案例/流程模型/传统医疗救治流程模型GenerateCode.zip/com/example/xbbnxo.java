package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "金融支付平台",
    tags = "金融支付平台"
)
@RestController
@RequestMapping("xbbnxo")
public class xbbnxo {
  @ApiOperation(
      value = "提供账单",
      notes = "提供账单"
  )
  @RequestMapping(
      value = "uchjfp",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> uchjfp(String[] args) {
    return null;
  }
}
