package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "村民",
    tags = "村民"
)
@RestController
@RequestMapping("bzhhwq")
public class bzhhwq {
  @ApiOperation(
      value = "登陆",
      notes = "登陆"
  )
  @RequestMapping(
      value = "itgqhd",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> itgqhd(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "下单",
      notes = "下单"
  )
  @RequestMapping(
      value = "zzvgoy",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> zzvgoy(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "收到取货通知",
      notes = "收到取货通知"
  )
  @RequestMapping(
      value = "jycgyi",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> jycgyi(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "取件",
      notes = "取件"
  )
  @RequestMapping(
      value = "xzjirq",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> xzjirq(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "确认收货",
      notes = "确认收货"
  )
  @RequestMapping(
      value = "ajdast",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> ajdast(String[] args) {
    return null;
  }
}
