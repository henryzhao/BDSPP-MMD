package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "支付宝",
    tags = "支付宝"
)
@RestController
@RequestMapping("ipmlqc")
public class ipmlqc {
  @ApiOperation(
      value = "村民支付",
      notes = "村民支付"
  )
  @RequestMapping(
      value = "zzzbwg",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> zzzbwg(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "返回支付完成信息",
      notes = "返回支付完成信息"
  )
  @RequestMapping(
      value = "cecrfw",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> cecrfw(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "佣金结算",
      notes = "佣金结算"
  )
  @RequestMapping(
      value = "xgoxzx",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> xgoxzx(String[] args) {
    return null;
  }
}
