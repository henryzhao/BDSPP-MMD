package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "签约商家",
    tags = "签约商家"
)
@RestController
@RequestMapping("bokjro")
public class bokjro {
  @ApiOperation(
      value = "确认订单",
      notes = "确认订单"
  )
  @RequestMapping(
      value = "nsdgft",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> nsdgft(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "打包发货",
      notes = "打包发货"
  )
  @RequestMapping(
      value = "eizmck",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> eizmck(String[] args) {
    return null;
  }
}
