package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "菜鸟物流",
    tags = "菜鸟物流"
)
@RestController
@RequestMapping("mbckur")
public class mbckur {
  @ApiOperation(
      value = "揽收货物",
      notes = "揽收货物"
  )
  @RequestMapping(
      value = "hcdmem",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> hcdmem(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "常规物流配送",
      notes = "常规物流配送"
  )
  @RequestMapping(
      value = "islexx",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> islexx(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "通知村民取件",
      notes = "通知村民取件"
  )
  @RequestMapping(
      value = "aekwom",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> aekwom(String[] args) {
    return null;
  }
}
