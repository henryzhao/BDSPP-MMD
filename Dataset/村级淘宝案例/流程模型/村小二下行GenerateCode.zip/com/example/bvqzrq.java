package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "支付宝",
    tags = "支付宝"
)
@RestController
@RequestMapping("bvqzrq")
public class bvqzrq {
  @ApiOperation(
      value = "村小二支付",
      notes = "村小二支付"
  )
  @RequestMapping(
      value = "ylpkla",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> ylpkla(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "返回支付完成信息",
      notes = "返回支付完成信息"
  )
  @RequestMapping(
      value = "lnuyie",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> lnuyie(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "佣金结算",
      notes = "佣金结算"
  )
  @RequestMapping(
      value = "asaweq",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> asaweq(String[] args) {
    return null;
  }
}
