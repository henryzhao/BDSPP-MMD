package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "村民",
    tags = "村民"
)
@RestController
@RequestMapping("mzwetw")
public class mzwetw {
  @ApiOperation(
      value = "登陆",
      notes = "登陆"
  )
  @RequestMapping(
      value = "zveqak",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> zveqak(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "收到取货通知",
      notes = "收到取货通知"
  )
  @RequestMapping(
      value = "yorapk",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> yorapk(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "取件",
      notes = "取件"
  )
  @RequestMapping(
      value = "sdiwce",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> sdiwce(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "确认收货",
      notes = "确认收货"
  )
  @RequestMapping(
      value = "aztmfu",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> aztmfu(String[] args) {
    return null;
  }
}
