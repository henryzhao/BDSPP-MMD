package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "县级服务中心",
    tags = "县级服务中心"
)
@RestController
@RequestMapping("lhacsr")
public class lhacsr {
  @ApiOperation(
      value = "县仓转换",
      notes = "县仓转换"
  )
  @RequestMapping(
      value = "eckkxf",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> eckkxf(String[] args) {
    return null;
  }
}
