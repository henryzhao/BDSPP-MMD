package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "农村淘宝",
    tags = "农村淘宝"
)
@RestController
@RequestMapping("omulge")
public class omulge {
  @ApiOperation(
      value = "村小二代购",
      notes = "村小二代购"
  )
  @RequestMapping(
      value = "uicgyc",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> uicgyc(String[] args) {
    return null;
  }
}
