package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "村小二",
    tags = "村小二"
)
@RestController
@RequestMapping("dthxgb")
public class dthxgb {
  @ApiOperation(
      value = "村小二拼单",
      notes = "村小二拼单"
  )
  @RequestMapping(
      value = "dcjbxx",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> dcjbxx(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "村小二代收",
      notes = "村小二代收"
  )
  @RequestMapping(
      value = "ixxdjb",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> ixxdjb(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "通知村民取件",
      notes = "通知村民取件"
  )
  @RequestMapping(
      value = "vaqldw",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> vaqldw(String[] args) {
    return null;
  }
}
