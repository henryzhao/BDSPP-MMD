package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "二段物流",
    tags = "二段物流"
)
@RestController
@RequestMapping("ankdcw")
public class ankdcw {
  @ApiOperation(
      value = "锁定村站",
      notes = "锁定村站"
  )
  @RequestMapping(
      value = "lzbbxg",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> lzbbxg(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "二级物流配送",
      notes = "二级物流配送"
  )
  @RequestMapping(
      value = "zprpvd",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> zprpvd(String[] args) {
    return null;
  }
}
