package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "签约商家",
    tags = "签约商家"
)
@RestController
@RequestMapping("wqewto")
public class wqewto {
  @ApiOperation(
      value = "确认订单",
      notes = "确认订单"
  )
  @RequestMapping(
      value = "dajexz",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> dajexz(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "打包发货",
      notes = "打包发货"
  )
  @RequestMapping(
      value = "zxtmss",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> zxtmss(String[] args) {
    return null;
  }
}
