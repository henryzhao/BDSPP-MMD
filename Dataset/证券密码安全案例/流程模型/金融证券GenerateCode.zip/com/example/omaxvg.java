package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "用户",
    tags = "用户"
)
@RestController
@RequestMapping("omaxvg")
public class omaxvg {
  @ApiOperation(
      value = "登录",
      notes = "登录"
  )
  @RequestMapping(
      value = "uyprfv",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> uyprfv(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "发起登录请求",
      notes = "发起登录请求"
  )
  @RequestMapping(
      value = "hrarjp",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> hrarjp(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "登录成功",
      notes = "登录成功"
  )
  @RequestMapping(
      value = "hjqtvo",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> hjqtvo(String[] args) {
    return null;
  }
}
