package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "证券交易平台",
    tags = "证券交易平台"
)
@RestController
@RequestMapping("mwdgnh")
public class mwdgnh {
  @ApiOperation(
      value = "获取登录信息",
      notes = "获取登录信息"
  )
  @RequestMapping(
      value = "ocpbzy",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> ocpbzy(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "用户身份认证",
      notes = "用户身份认证"
  )
  @RequestMapping(
      value = "huwjyd",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> huwjyd(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "建立业务连接",
      notes = "建立业务连接"
  )
  @RequestMapping(
      value = "yiqrkq",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> yiqrkq(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "验证登录请求",
      notes = "验证登录请求"
  )
  @RequestMapping(
      value = "ojmtgq",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> ojmtgq(String[] args) {
    return null;
  }
}
