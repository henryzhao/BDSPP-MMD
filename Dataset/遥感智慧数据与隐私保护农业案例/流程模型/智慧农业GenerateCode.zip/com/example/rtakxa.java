package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "智慧农业系统",
    tags = "智慧农业系统"
)
@RestController
@RequestMapping("rtakxa")
public class rtakxa {
  @ApiOperation(
      value = "喷灌控制",
      notes = "喷灌控制"
  )
  @RequestMapping(
      value = "jlczpo",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> jlczpo(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "光照控制",
      notes = "光照控制"
  )
  @RequestMapping(
      value = "pkluro",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> pkluro(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "风机控制",
      notes = "风机控制"
  )
  @RequestMapping(
      value = "poakkq",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> poakkq(String[] args) {
    return null;
  }
}
