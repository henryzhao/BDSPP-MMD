package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "用户",
    tags = "用户"
)
@RestController
@RequestMapping("sxeokz")
public class sxeokz {
  @ApiOperation(
      value = "提出数据需求",
      notes = "提出数据需求"
  )
  @RequestMapping(
      value = "rbzete",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> rbzete(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "获取数据",
      notes = "获取数据"
  )
  @RequestMapping(
      value = "zesgym",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> zesgym(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "数据反馈",
      notes = "数据反馈"
  )
  @RequestMapping(
      value = "jejars",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> jejars(String[] args) {
    return null;
  }
}
