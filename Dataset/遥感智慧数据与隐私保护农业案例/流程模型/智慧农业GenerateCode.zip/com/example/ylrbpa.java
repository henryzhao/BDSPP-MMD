package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "人工信息采集",
    tags = "人工信息采集"
)
@RestController
@RequestMapping("ylrbpa")
public class ylrbpa {
  @ApiOperation(
      value = "视频采集棚内病虫害信息",
      notes = "视频采集棚内病虫害信息"
  )
  @RequestMapping(
      value = "lzmynz",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> lzmynz(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "气象采集温湿度信息",
      notes = "气象采集温湿度信息"
  )
  @RequestMapping(
      value = "zqvdsj",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> zqvdsj(String[] args) {
    return null;
  }
}
