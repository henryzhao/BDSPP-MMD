package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "农户",
    tags = "农户"
)
@RestController
@RequestMapping("fyazlh")
public class fyazlh {
  @ApiOperation(
      value = "科学种植",
      notes = "科学种植"
  )
  @RequestMapping(
      value = "mllbxa",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> mllbxa(String[] args) {
    return null;
  }
}
