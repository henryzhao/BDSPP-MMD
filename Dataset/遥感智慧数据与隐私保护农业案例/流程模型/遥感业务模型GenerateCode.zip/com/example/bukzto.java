package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "政府机构",
    tags = "政府机构"
)
@RestController
@RequestMapping("bukzto")
public class bukzto {
  @ApiOperation(
      value = "农业监管",
      notes = "农业监管"
  )
  @RequestMapping(
      value = "hyhgak",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> hyhgak(String[] args) {
    return null;
  }
}
