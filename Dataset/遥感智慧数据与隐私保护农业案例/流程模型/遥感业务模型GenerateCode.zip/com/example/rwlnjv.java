package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "卫星接收节点",
    tags = "卫星接收节点"
)
@RestController
@RequestMapping("rwlnjv")
public class rwlnjv {
  @ApiOperation(
      value = "接收卫星数据",
      notes = "接收卫星数据"
  )
  @RequestMapping(
      value = "yvkecq",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> yvkecq(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "数据转发",
      notes = "数据转发"
  )
  @RequestMapping(
      value = "krsurx",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> krsurx(String[] args) {
    return null;
  }
}
