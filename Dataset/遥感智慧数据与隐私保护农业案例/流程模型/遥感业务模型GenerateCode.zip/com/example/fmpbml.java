package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "跨界服务平台",
    tags = "跨界服务平台"
)
@RestController
@RequestMapping("fmpbml")
public class fmpbml {
  @ApiOperation(
      value = "数据入库",
      notes = "数据入库"
  )
  @RequestMapping(
      value = "bcprwk",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> bcprwk(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "服务开发",
      notes = "服务开发"
  )
  @RequestMapping(
      value = "nmokqk",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> nmokqk(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "服务开放",
      notes = "服务开放"
  )
  @RequestMapping(
      value = "gvlxrk",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> gvlxrk(String[] args) {
    return null;
  }
}
