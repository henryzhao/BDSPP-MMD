package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "地方网监机构",
    tags = "地方网监机构"
)
@RestController
@RequestMapping("meefxv")
public class meefxv {
  @ApiOperation(
      value = "网监审计",
      notes = "网监审计"
  )
  @RequestMapping(
      value = "cmgsic",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> cmgsic(String[] args) {
    return null;
  }
}
