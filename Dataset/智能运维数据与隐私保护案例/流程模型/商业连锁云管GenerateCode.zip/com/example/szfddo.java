package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "云管平台",
    tags = "云管平台"
)
@RestController
@RequestMapping("szfddo")
public class szfddo {
  @ApiOperation(
      value = "客户身份认证",
      notes = "客户身份认证"
  )
  @RequestMapping(
      value = "loglrj",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> loglrj(String[] args) {
    return null;
  }
}
