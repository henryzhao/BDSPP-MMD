package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "门店",
    tags = "门店"
)
@RestController
@RequestMapping("oewqeo")
public class oewqeo {
  @ApiOperation(
      value = "网络服务",
      notes = "网络服务"
  )
  @RequestMapping(
      value = "qgenqq",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> qgenqq(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "商品推荐",
      notes = "商品推荐"
  )
  @RequestMapping(
      value = "hkosyu",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> hkosyu(String[] args) {
    return null;
  }
}
