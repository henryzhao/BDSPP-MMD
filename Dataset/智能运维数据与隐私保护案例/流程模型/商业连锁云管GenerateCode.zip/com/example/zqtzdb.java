package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "第三方支付公司",
    tags = "第三方支付公司"
)
@RestController
@RequestMapping("zqtzdb")
public class zqtzdb {
  @ApiOperation(
      value = "支付",
      notes = "支付"
  )
  @RequestMapping(
      value = "xtaddg",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> xtaddg(String[] args) {
    return null;
  }
}
