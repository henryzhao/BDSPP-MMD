package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "保险公司",
    tags = "保险公司"
)
@RestController
@RequestMapping("mqamkf")
public class mqamkf {
  @ApiOperation(
      value = "保险公司接收保单数据",
      notes = "保险公司接收保单数据"
  )
  @RequestMapping(
      value = "jotsfm",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> jotsfm(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "保险公司承保",
      notes = "保险公司承保"
  )
  @RequestMapping(
      value = "lhhfvr",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> lhhfvr(String[] args) {
    return null;
  }
}
