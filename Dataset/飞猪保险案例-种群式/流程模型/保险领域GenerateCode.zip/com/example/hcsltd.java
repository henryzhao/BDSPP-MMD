package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "蚂蚁保险",
    tags = "蚂蚁保险"
)
@RestController
@RequestMapping("hcsltd")
public class hcsltd {
  @ApiOperation(
      value = "蚂蚁保险接收用户请求",
      notes = "蚂蚁保险接收用户请求"
  )
  @RequestMapping(
      value = "eledbc",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> eledbc(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "蚂蚁保险返回推荐险种",
      notes = "蚂蚁保险返回推荐险种"
  )
  @RequestMapping(
      value = "rxlvzu",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> rxlvzu(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "接收订单",
      notes = "接收订单"
  )
  @RequestMapping(
      value = "rvofuj",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> rvofuj(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "系统创建保单",
      notes = "系统创建保单"
  )
  @RequestMapping(
      value = "antnmp",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> antnmp(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "跳转至收银台",
      notes = "跳转至收银台"
  )
  @RequestMapping(
      value = "ljrtwf",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> ljrtwf(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "保险出单",
      notes = "保险出单"
  )
  @RequestMapping(
      value = "cqpyeq",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> cqpyeq(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "发送保单数据",
      notes = "发送保单数据"
  )
  @RequestMapping(
      value = "kgxocy",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> kgxocy(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "蚂蚁保险扣除服务费用",
      notes = "蚂蚁保险扣除服务费用"
  )
  @RequestMapping(
      value = "upmqqa",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> upmqqa(String[] args) {
    return null;
  }
}
