package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "用户",
    tags = "用户"
)
@RestController
@RequestMapping("tpnmdj")
public class tpnmdj {
  @ApiOperation(
      value = "用户请求保险信息",
      notes = "用户请求保险信息"
  )
  @RequestMapping(
      value = "pjbxhk",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> pjbxhk(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "用户选择保险",
      notes = "用户选择保险"
  )
  @RequestMapping(
      value = "cvsbqv",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> cvsbqv(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "提交订单",
      notes = "提交订单"
  )
  @RequestMapping(
      value = "suozzr",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> suozzr(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "用户支付",
      notes = "用户支付"
  )
  @RequestMapping(
      value = "zqrhzd",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> zqrhzd(String[] args) {
    return null;
  }
}
