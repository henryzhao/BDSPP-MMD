package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "客户",
    tags = "客户"
)
@RestController
@RequestMapping("ynzyvr")
public class ynzyvr {
  @ApiOperation(
      value = "购买商品",
      notes = "购买商品"
  )
  @RequestMapping(
      value = "eidrdl",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> eidrdl(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "支付",
      notes = "支付"
  )
  @RequestMapping(
      value = "tulchy",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> tulchy(String[] args) {
    return null;
  }
}
