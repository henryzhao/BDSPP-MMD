package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "总部管理者",
    tags = "总部管理者"
)
@RestController
@RequestMapping("rjyylz")
public class rjyylz {
  @ApiOperation(
      value = "巡查门店",
      notes = "巡查门店"
  )
  @RequestMapping(
      value = "oekjfa",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> oekjfa(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "网监审计",
      notes = "网监审计"
  )
  @RequestMapping(
      value = "jfdjfp",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> jfdjfp(String[] args) {
    return null;
  }
}
