package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "门店",
    tags = "门店"
)
@RestController
@RequestMapping("wuqztx")
public class wuqztx {
  @ApiOperation(
      value = "推销商品",
      notes = "推销商品"
  )
  @RequestMapping(
      value = "yirpoa",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> yirpoa(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "运营信息",
      notes = "运营信息"
  )
  @RequestMapping(
      value = "koxtam",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> koxtam(String[] args) {
    return null;
  }
}
