package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "基站节点",
    tags = "基站节点"
)
@RestController
@RequestMapping("vvamsj")
public class vvamsj {
  @ApiOperation(
      value = "制定数据采集计划",
      notes = "制定数据采集计划"
  )
  @RequestMapping(
      value = "iqrtwm",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> iqrtwm(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "卫星拍摄获取地图数据",
      notes = "卫星拍摄获取地图数据"
  )
  @RequestMapping(
      value = "wqmcjw",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> wqmcjw(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "地面节点采集温度湿度数据",
      notes = "地面节点采集温度湿度数据"
  )
  @RequestMapping(
      value = "hdolty",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> hdolty(String[] args) {
    return null;
  }
}
