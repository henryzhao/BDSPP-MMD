package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "用户",
    tags = "用户"
)
@RestController
@RequestMapping("mrpggd")
public class mrpggd {
  @ApiOperation(
      value = "提出数据需求",
      notes = "提出数据需求"
  )
  @RequestMapping(
      value = "wkzhzw",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> wkzhzw(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "用户支付",
      notes = "用户支付"
  )
  @RequestMapping(
      value = "wgkpvg",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> wgkpvg(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "获取数据",
      notes = "获取数据"
  )
  @RequestMapping(
      value = "uiitlq",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> uiitlq(String[] args) {
    return null;
  }
}
