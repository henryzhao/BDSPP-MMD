package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "服务平台",
    tags = "服务平台"
)
@RestController
@RequestMapping("ukddvs")
public class ukddvs {
  @ApiOperation(
      value = "数据整合处理",
      notes = "数据整合处理"
  )
  @RequestMapping(
      value = "usdquo",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> usdquo(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "数据在线应用",
      notes = "数据在线应用"
  )
  @RequestMapping(
      value = "uvnpmr",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> uvnpmr(String[] args) {
    return null;
  }
}
