package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "飞猪",
    tags = "飞猪"
)
@RestController
@RequestMapping("gvjbow")
public class gvjbow {
  @ApiOperation(
      value = "返回机票信息",
      notes = "返回机票信息"
  )
  @RequestMapping(
      value = "izihsk",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> izihsk(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "返回机票订单信息",
      notes = "返回机票订单信息"
  )
  @RequestMapping(
      value = "atcvgh",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> atcvgh(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "跳转至收银台",
      notes = "跳转至收银台"
  )
  @RequestMapping(
      value = "juhmea",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> juhmea(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "接收用户请求",
      notes = "接收用户请求"
  )
  @RequestMapping(
      value = "esjkgk",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> esjkgk(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "接收订单",
      notes = "接收订单"
  )
  @RequestMapping(
      value = "sozedd",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> sozedd(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "发送机票订单数据",
      notes = "发送机票订单数据"
  )
  @RequestMapping(
      value = "gdhggz",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> gdhggz(String[] args) {
    return null;
  }
}
