package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "用户",
    tags = "用户"
)
@RestController
@RequestMapping("ifqvpf")
public class ifqvpf {
  @ApiOperation(
      value = "请求机票信息",
      notes = "请求机票信息"
  )
  @RequestMapping(
      value = "hbtpyf",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> hbtpyf(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "返回机票订单成功信息",
      notes = "返回机票订单成功信息"
  )
  @RequestMapping(
      value = "mqcdoi",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> mqcdoi(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "选择航班",
      notes = "选择航班"
  )
  @RequestMapping(
      value = "kewwga",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> kewwga(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "提交机票订单",
      notes = "提交机票订单"
  )
  @RequestMapping(
      value = "kerlzt",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> kerlzt(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "提交酒店预定请求",
      notes = "提交酒店预定请求"
  )
  @RequestMapping(
      value = "idclao",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> idclao(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "提交预定信息",
      notes = "提交预定信息"
  )
  @RequestMapping(
      value = "zeywfa",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> zeywfa(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "支付",
      notes = "支付"
  )
  @RequestMapping(
      value = "reerzd",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> reerzd(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "客房预定成功",
      notes = "客房预定成功"
  )
  @RequestMapping(
      value = "jukvmx",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> jukvmx(String[] args) {
    return null;
  }
}
