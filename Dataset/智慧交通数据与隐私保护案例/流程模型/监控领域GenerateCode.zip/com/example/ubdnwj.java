package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "交管局",
    tags = "交管局"
)
@RestController
@RequestMapping("ubdnwj")
public class ubdnwj {
  @ApiOperation(
      value = "登陆",
      notes = "登陆"
  )
  @RequestMapping(
      value = "hjwbld",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> hjwbld(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "采集车辆信息",
      notes = "采集车辆信息"
  )
  @RequestMapping(
      value = "sxowea",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> sxowea(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "生成路况调度信息",
      notes = "生成路况调度信息"
  )
  @RequestMapping(
      value = "nxmuqd",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> nxmuqd(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "执行调度策略",
      notes = "执行调度策略"
  )
  @RequestMapping(
      value = "eatyxp",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> eatyxp(String[] args) {
    return null;
  }
}
