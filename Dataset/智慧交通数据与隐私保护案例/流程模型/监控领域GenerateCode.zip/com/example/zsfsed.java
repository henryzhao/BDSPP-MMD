package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "交通管理平台",
    tags = "交通管理平台"
)
@RestController
@RequestMapping("zsfsed")
public class zsfsed {
  @ApiOperation(
      value = "身份认证",
      notes = "身份认证"
  )
  @RequestMapping(
      value = "ajqmfb",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> ajqmfb(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "监控车辆",
      notes = "监控车辆"
  )
  @RequestMapping(
      value = "yhygkv",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> yhygkv(String[] args) {
    return null;
  }
}
