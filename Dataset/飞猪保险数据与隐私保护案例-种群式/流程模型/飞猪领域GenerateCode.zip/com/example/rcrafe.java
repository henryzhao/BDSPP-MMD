package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "飞猪",
    tags = "飞猪"
)
@RestController
@RequestMapping("rcrafe")
public class rcrafe {
  @ApiOperation(
      value = "提交订单信息",
      notes = "提交订单信息"
  )
  @RequestMapping(
      value = "zrvtav",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> zrvtav(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "跳转至收银台",
      notes = "跳转至收银台"
  )
  @RequestMapping(
      value = "zphbkp",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> zphbkp(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "支付佣金给飞猪平台",
      notes = "支付佣金给飞猪平台"
  )
  @RequestMapping(
      value = "poqsxu",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> poqsxu(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "飞猪发送订单失败信息",
      notes = "飞猪发送订单失败信息"
  )
  @RequestMapping(
      value = "yhptyl",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> yhptyl(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "关闭订单并退费",
      notes = "关闭订单并退费"
  )
  @RequestMapping(
      value = "lqecin",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> lqecin(String[] args) {
    return null;
  }
}
