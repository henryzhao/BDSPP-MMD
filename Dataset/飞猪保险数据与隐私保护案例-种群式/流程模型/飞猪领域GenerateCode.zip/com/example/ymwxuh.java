package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "用户",
    tags = "用户"
)
@RestController
@RequestMapping("ymwxuh")
public class ymwxuh {
  @ApiOperation(
      value = "用户浏览酒店信息",
      notes = "用户浏览酒店信息"
  )
  @RequestMapping(
      value = "maydmw",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> maydmw(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "用户选择酒店并提交订单",
      notes = "用户选择酒店并提交订单"
  )
  @RequestMapping(
      value = "naheux",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> naheux(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "用户支付",
      notes = "用户支付"
  )
  @RequestMapping(
      value = "bfyqsd",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> bfyqsd(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "提交订单最终结果",
      notes = "提交订单最终结果"
  )
  @RequestMapping(
      value = "altylo",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> altylo(String[] args) {
    return null;
  }
}
