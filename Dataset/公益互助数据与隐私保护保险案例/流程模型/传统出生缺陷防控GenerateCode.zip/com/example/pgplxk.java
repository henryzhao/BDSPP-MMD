package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "出生缺陷综合防治网络",
    tags = "出生缺陷综合防治网络"
)
@RestController
@RequestMapping("pgplxk")
public class pgplxk {
  @ApiOperation(
      value = "出生缺陷检测",
      notes = "出生缺陷检测"
  )
  @RequestMapping(
      value = "ciymmd",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> ciymmd(String[] args) {
    return null;
  }
}
