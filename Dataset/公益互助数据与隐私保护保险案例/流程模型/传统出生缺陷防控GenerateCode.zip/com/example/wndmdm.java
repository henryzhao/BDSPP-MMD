package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "孕妇",
    tags = "孕妇"
)
@RestController
@RequestMapping("wndmdm")
public class wndmdm {
  @ApiOperation(
      value = "孕检",
      notes = "孕检"
  )
  @RequestMapping(
      value = "blsfaj",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> blsfaj(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "申请救助",
      notes = "申请救助"
  )
  @RequestMapping(
      value = "nxmbuz",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> nxmbuz(String[] args) {
    return null;
  }
}
