package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "数字证书系统",
    tags = "数字证书系统"
)
@RestController
@RequestMapping("smourw")
public class smourw {
  @ApiOperation(
      value = "审核证书申请",
      notes = "审核证书申请"
  )
  @RequestMapping(
      value = "zclual",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> zclual(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "签发证书",
      notes = "签发证书"
  )
  @RequestMapping(
      value = "gazprj",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> gazprj(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "下发证书",
      notes = "下发证书"
  )
  @RequestMapping(
      value = "rckzlh",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> rckzlh(String[] args) {
    return null;
  }
}
