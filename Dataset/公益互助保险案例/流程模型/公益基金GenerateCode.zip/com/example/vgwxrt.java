package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "保险公司",
    tags = "保险公司"
)
@RestController
@RequestMapping("vgwxrt")
public class vgwxrt {
  @ApiOperation(
      value = "提供保险推荐购买服务",
      notes = "提供保险推荐购买服务"
  )
  @RequestMapping(
      value = "uvfxfw",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> uvfxfw(String[] args) {
    return null;
  }
}
