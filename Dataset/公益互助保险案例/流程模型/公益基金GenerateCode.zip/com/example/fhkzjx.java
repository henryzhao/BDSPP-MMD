package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "爱心人士",
    tags = "爱心人士"
)
@RestController
@RequestMapping("fhkzjx")
public class fhkzjx {
  @ApiOperation(
      value = "获得捐赠物品",
      notes = "获得捐赠物品"
  )
  @RequestMapping(
      value = "dcxnnv",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> dcxnnv(String[] args) {
    return null;
  }
}
