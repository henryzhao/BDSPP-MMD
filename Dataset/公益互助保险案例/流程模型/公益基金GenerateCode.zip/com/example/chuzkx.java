package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "出生缺陷综合防治网络",
    tags = "出生缺陷综合防治网络"
)
@RestController
@RequestMapping("chuzkx")
public class chuzkx {
  @ApiOperation(
      value = "出生缺陷检测",
      notes = "出生缺陷检测"
  )
  @RequestMapping(
      value = "bmatba",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> bmatba(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "提供检测报告",
      notes = "提供检测报告"
  )
  @RequestMapping(
      value = "vgoevk",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> vgoevk(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "提供赠送或推荐保险入口",
      notes = "提供赠送或推荐保险入口"
  )
  @RequestMapping(
      value = "vvujsf",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> vvujsf(String[] args) {
    return null;
  }
}
