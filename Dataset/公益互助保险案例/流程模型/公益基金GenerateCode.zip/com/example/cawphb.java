package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "基金会",
    tags = "基金会"
)
@RestController
@RequestMapping("cawphb")
public class cawphb {
  @ApiOperation(
      value = "进行救助",
      notes = "进行救助"
  )
  @RequestMapping(
      value = "xvkrwd",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> xvkrwd(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "自行采购后义卖",
      notes = "自行采购后义卖"
  )
  @RequestMapping(
      value = "qanrkt",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> qanrkt(String[] args) {
    return null;
  }
}
