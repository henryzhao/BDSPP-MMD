package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "酒店",
    tags = "酒店"
)
@RestController
@RequestMapping("gyrmom")
public class gyrmom {
  @ApiOperation(
      value = "确定客房预定信息",
      notes = "确定客房预定信息"
  )
  @RequestMapping(
      value = "dmqxoz",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> dmqxoz(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "客房预留",
      notes = "客房预留"
  )
  @RequestMapping(
      value = "gamcfe",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> gamcfe(String[] args) {
    return null;
  }
}
