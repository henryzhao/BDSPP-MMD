package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "航空公司",
    tags = "航空公司"
)
@RestController
@RequestMapping("flncmh")
public class flncmh {
  @ApiOperation(
      value = "航空公司接收机票订单数据",
      notes = "航空公司接收机票订单数据"
  )
  @RequestMapping(
      value = "iglpzn",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> iglpzn(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "机票出票",
      notes = "机票出票"
  )
  @RequestMapping(
      value = "rafmlu",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> rafmlu(String[] args) {
    return null;
  }
}
