package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "用户",
    tags = "用户"
)
@RestController
@RequestMapping("ryhbcc")
public class ryhbcc {
  @ApiOperation(
      value = "请求机票信息",
      notes = "请求机票信息"
  )
  @RequestMapping(
      value = "woyakk",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> woyakk(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "选择航班",
      notes = "选择航班"
  )
  @RequestMapping(
      value = "dfragv",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> dfragv(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "提交机票订单",
      notes = "提交机票订单"
  )
  @RequestMapping(
      value = "uraarw",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> uraarw(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "支付",
      notes = "支付"
  )
  @RequestMapping(
      value = "sqksbr",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> sqksbr(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "返回机票成功信息",
      notes = "返回机票成功信息"
  )
  @RequestMapping(
      value = "pffjfu",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> pffjfu(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "提交酒店预定请求",
      notes = "提交酒店预定请求"
  )
  @RequestMapping(
      value = "kyuzbp",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> kyuzbp(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "提交预定信息",
      notes = "提交预定信息"
  )
  @RequestMapping(
      value = "fansje",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> fansje(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "接受预定信息",
      notes = "接受预定信息"
  )
  @RequestMapping(
      value = "cgvxmt",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> cgvxmt(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "客房预定成功",
      notes = "客房预定成功"
  )
  @RequestMapping(
      value = "zkmsir",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> zkmsir(String[] args) {
    return null;
  }
}
