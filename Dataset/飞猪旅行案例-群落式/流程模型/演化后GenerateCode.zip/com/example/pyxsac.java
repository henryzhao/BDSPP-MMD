package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "飞猪",
    tags = "飞猪"
)
@RestController
@RequestMapping("pyxsac")
public class pyxsac {
  @ApiOperation(
      value = "接收用户请求",
      notes = "接收用户请求"
  )
  @RequestMapping(
      value = "dzokze",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> dzokze(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "返回机票信息",
      notes = "返回机票信息"
  )
  @RequestMapping(
      value = "bibyew",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> bibyew(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "接收订单",
      notes = "接收订单"
  )
  @RequestMapping(
      value = "tpnjrp",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> tpnjrp(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "跳转至收银台",
      notes = "跳转至收银台"
  )
  @RequestMapping(
      value = "lkndkh",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> lkndkh(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "发送机票订单数据",
      notes = "发送机票订单数据"
  )
  @RequestMapping(
      value = "rqgxiz",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> rqgxiz(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "返回机票订单信息",
      notes = "返回机票订单信息"
  )
  @RequestMapping(
      value = "qzmtmf",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> qzmtmf(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "接受酒店预定请求",
      notes = "接受酒店预定请求"
  )
  @RequestMapping(
      value = "umqqay",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> umqqay(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "查询酒店客房信息",
      notes = "查询酒店客房信息"
  )
  @RequestMapping(
      value = "dfpsyb",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> dfpsyb(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "返回客房信息",
      notes = "返回客房信息"
  )
  @RequestMapping(
      value = "mdokbu",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> mdokbu(String[] args) {
    return null;
  }
}
