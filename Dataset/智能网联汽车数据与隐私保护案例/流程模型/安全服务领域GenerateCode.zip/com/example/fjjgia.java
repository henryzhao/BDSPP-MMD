package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "安全证书认证机构",
    tags = "安全证书认证机构"
)
@RestController
@RequestMapping("fjjgia")
public class fjjgia {
  @ApiOperation(
      value = "签发证书",
      notes = "签发证书"
  )
  @RequestMapping(
      value = "kjqcsp",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> kjqcsp(String[] args) {
    return null;
  }
}
