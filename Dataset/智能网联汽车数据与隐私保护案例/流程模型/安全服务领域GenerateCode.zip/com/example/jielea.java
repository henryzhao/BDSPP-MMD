package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "智能网联汽车",
    tags = "智能网联汽车"
)
@RestController
@RequestMapping("jielea")
public class jielea {
  @ApiOperation(
      value = "上传车辆状态",
      notes = "上传车辆状态"
  )
  @RequestMapping(
      value = "mwfewz",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> mwfewz(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "车辆验签",
      notes = "车辆验签"
  )
  @RequestMapping(
      value = "kwyjba",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> kwyjba(String[] args) {
    return null;
  }
}
