package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "汽车制造商",
    tags = "汽车制造商"
)
@RestController
@RequestMapping("xyczxi")
public class xyczxi {
  @ApiOperation(
      value = "获取车辆信息",
      notes = "获取车辆信息"
  )
  @RequestMapping(
      value = "vyfdqr",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> vyfdqr(String[] args) {
    return null;
  }
}
