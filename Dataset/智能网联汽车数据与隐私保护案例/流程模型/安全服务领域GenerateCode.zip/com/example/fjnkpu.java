package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "安全服务提供商",
    tags = "安全服务提供商"
)
@RestController
@RequestMapping("fjnkpu")
public class fjnkpu {
  @ApiOperation(
      value = "申请证书",
      notes = "申请证书"
  )
  @RequestMapping(
      value = "vsdfkc",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> vsdfkc(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "应用证书",
      notes = "应用证书"
  )
  @RequestMapping(
      value = "iprypq",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> iprypq(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "身份认证",
      notes = "身份认证"
  )
  @RequestMapping(
      value = "nkabnm",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> nkabnm(String[] args) {
    return null;
  }
}
