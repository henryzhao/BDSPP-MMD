package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "交管局",
    tags = "交管局"
)
@RestController
@RequestMapping("ldxayy")
public class ldxayy {
  @ApiOperation(
      value = "等待放行",
      notes = "等待放行"
  )
  @RequestMapping(
      value = "vwmwtl",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> vwmwtl(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "继续行驶",
      notes = "继续行驶"
  )
  @RequestMapping(
      value = "khrhxq",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> khrhxq(String[] args) {
    return null;
  }
}
