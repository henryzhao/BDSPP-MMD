package com.example;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.lang.String;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
    value = "车主",
    tags = "车主"
)
@RestController
@RequestMapping("cvfptn")
public class cvfptn {
  @ApiOperation(
      value = "驾驶车辆",
      notes = "驾驶车辆"
  )
  @RequestMapping(
      value = "lavkqm",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> lavkqm(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "选择道路信息",
      notes = "选择道路信息"
  )
  @RequestMapping(
      value = "wnmvsi",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> wnmvsi(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "查看停车信息",
      notes = "查看停车信息"
  )
  @RequestMapping(
      value = "qsdxbd",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> qsdxbd(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "车位信息采集",
      notes = "车位信息采集"
  )
  @RequestMapping(
      value = "ecksme",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> ecksme(String[] args) {
    return null;
  }

  @ApiOperation(
      value = "在指定车位停车",
      notes = "在指定车位停车"
  )
  @RequestMapping(
      value = "byfvis",
      method = RequestMethod.GET
  )
  @Transactional(
      rollbackFor = Exception.class
  )
  @RequestBody
  public Map<String, String> byfvis(String[] args) {
    return null;
  }
}
